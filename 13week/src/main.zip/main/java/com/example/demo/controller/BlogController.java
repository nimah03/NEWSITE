package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.Optional;
import com.example.demo.model.domain.Article;
import com.example.demo.model.domain.TestDB;
import com.example.demo.model.service.AddArticleRequest;
import com.example.demo.model.service.BlogService;
import com.example.demo.model.service.TestService; // 'Testservice' -> 'TestService'로 수정

@Controller
public class BlogController {

    // 클래스명을 관례에 따라 'TestService'로 가정하고 수정합니다.
    @Autowired
    TestService testService; 

    @Autowired
    private BlogService blogService;

    // 중복 없던 경로 유지
    @GetMapping("/article_list")
    public String article_list(Model model) {
        List<Article> list = blogService.findAll();
        model.addAttribute("articles", list);
        return "article_list";
    }

    // DemoController에서 삭제되었으므로 충돌 해결.
    @GetMapping("/hello") // 전송 방식
    public String hello(Model model) {
        model.addAttribute("data", " 방갑습니다."); // model 설정
        return "hello"; // hello.html 연결
    }

    // DemoController에서 경로가 변경되었으므로 충돌 해결.
    @GetMapping("/about_detailed")
    public String about_detailed() {
        return "about_detailed";
    }


    @GetMapping("/article_edit/{id}") // 게시판 링크 지정
    public String article_edit(Model model, @PathVariable Long id) {
        Optional<Article> list = blogService.findById(id); 
        if (list.isPresent()) {
            model.addAttribute("article", list.get());
        } else {
            return "/error_page/article_error";
        }
        return "article_edit";
    }

    @PutMapping("/api/article_edit/{id}")
    public String updateArticle(@PathVariable Long id, @ModelAttribute AddArticleRequest request) {
        blogService.update(id, request);
        return "redirect:/article_list";
    }

    @DeleteMapping("/api/article_delete/{id}")
    public String deleteArticle(@PathVariable Long id) {
        blogService.delete(id);
        return "redirect:/article_list";
    }

    // 이 매핑은 DemoController에 없었으므로 그대로 유지
    @GetMapping("/testdb")
    public String getAllTestDBs(Model model) {
        // Testservice -> testService로 변경하여 사용
        TestDB test1 = testService.findByName("홍길동"); 
        TestDB test2 = testService.findById(2);
        TestDB test3 = testService.findById(3);

        model.addAttribute("data1", test1);
        model.addAttribute("data2", test2);
        model.addAttribute("data3", test3);

        System.out.println("데이터1 출력 디버그 : " + test1);
        System.out.println("데이터2 출력 디버그 : " + test2);
        System.out.println("데이터3 출력 디버그 : " + test3);

        return "testdb";
    }
}