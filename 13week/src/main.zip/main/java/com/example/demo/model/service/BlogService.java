package com.example.demo.model.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.model.domain.Article;
import com.example.demo.model.repository.BlogRepository;

@Service
public class BlogService {

    private final BlogRepository blogRepository;

    public BlogService(BlogRepository blogRepository) {
        this.blogRepository = blogRepository;
    }

    // 전체 조회
    public List<Article> findAll() {
        return blogRepository.findAll();
    }

    // 단일 조회
    public Optional<Article> findById(Long id) {
        return blogRepository.findById(id);
    }

    // 수정
    public Article update(Long id, AddArticleRequest request) {
        return blogRepository.findById(id)
                .map(article -> {
                    article.setTitle(request.getTitle());
                    article.setContent(request.getContent());
                    return blogRepository.save(article);
                })
                .orElseThrow(() -> new IllegalArgumentException("없는 게시글입니다."));
    }

    // 삭제
    public void delete(Long id) {
        blogRepository.deleteById(id);
    }

    // 생성
    public Article save(AddArticleRequest request) {
        Article article = new Article(
                request.getTitle(),
                request.getContent()
        );
        return blogRepository.save(article);
    }
}
